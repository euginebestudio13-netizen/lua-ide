package com.luaide.app

import android.os.Bundle
import android.text.Editable
import android.text.TextWatcher
import android.widget.EditText
import android.widget.ImageButton
import android.widget.TextView
import android.widget.Toast
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.app.AppCompatActivity
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import org.luaj.vm2.LuaError
import org.luaj.vm2.LuaValue
import org.luaj.vm2.Varargs
import org.luaj.vm2.lib.OneArgFunction
import org.luaj.vm2.lib.VarArgFunction
import org.luaj.vm2.lib.jse.JsePlatform

class MainActivity : AppCompatActivity() {

    private lateinit var editor: EditText
    private lateinit var lineNumbers: TextView
    private lateinit var output: TextView
    private lateinit var tvFileName: TextView
    private lateinit var fileManager: FileManager

    private var currentFileName: String? = null
    private var isHighlighting = false

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        fileManager = FileManager(this)

        editor = findViewById(R.id.editor)
        lineNumbers = findViewById(R.id.tvLineNumbers)
        output = findViewById(R.id.tvOutput)
        tvFileName = findViewById(R.id.tvFileName)

        findViewById<ImageButton>(R.id.btnRun).setOnClickListener { runLua() }
        findViewById<ImageButton>(R.id.btnSave).setOnClickListener { saveFile() }
        findViewById<ImageButton>(R.id.btnFiles).setOnClickListener { showFileExplorer() }
        findViewById<ImageButton>(R.id.btnClearOutput).setOnClickListener { output.text = "" }

        setupEditorWatchers()

        // Seed a starter script the first time the app runs
        if (fileManager.listScripts().isEmpty()) {
            editor.setText(
                "-- Welcome to Lua IDE\n" +
                "-- Tap the ▶ button to run this script\n\n" +
                "local function greet(name)\n" +
                "    return \"Hello, \" .. name .. \"!\"\n" +
                "end\n\n" +
                "print(greet(\"world\"))\n\n" +
                "for i = 1, 5 do\n" +
                "    print(\"count: \" .. i)\n" +
                "end\n"
            )
        }
    }

    private fun setupEditorWatchers() {
        editor.addTextChangedListener(object : TextWatcher {
            override fun beforeTextChanged(s: CharSequence?, a: Int, b: Int, c: Int) {}
            override fun onTextChanged(s: CharSequence?, a: Int, b: Int, c: Int) {}
            override fun afterTextChanged(s: Editable?) {
                if (s == null || isHighlighting) return
                isHighlighting = true
                LuaHighlighter.highlight(s)
                isHighlighting = false
                updateLineNumbers(s.toString())
            }
        })
        updateLineNumbers("")
    }

    private fun updateLineNumbers(text: String) {
        val lines = text.count { it == '\n' } + 1
        val sb = StringBuilder()
        for (i in 1..lines) {
            sb.append(i)
            if (i != lines) sb.append('\n')
        }
        lineNumbers.text = sb.toString()
    }

    /** Runs the current editor content through LuaJ off the main thread. */
    private fun runLua() {
        val code = editor.text.toString()
        output.text = ""
        appendOutput("Running...\n")

        CoroutineScope(Dispatchers.Main).launch {
            val result = withContext(Dispatchers.Default) {
                executeLua(code)
            }
            output.text = result
        }
    }

    private fun executeLua(code: String): String {
        val log = StringBuilder()
        try {
            val globals = JsePlatform.standardGlobals()

            // Redirect print() into our console instead of stdout
            globals.set("print", object : VarArgFunction() {
                override fun invoke(args: Varargs): Varargs {
                    val parts = (1..args.narg()).map { args.arg(it).tojstring() }
                    log.append(parts.joinToString("\t")).append('\n')
                    return LuaValue.NONE
                }
            })

            val chunk = globals.load(code, "script")
            chunk.call()

            if (log.isEmpty()) log.append("(no output)")
        } catch (e: LuaError) {
            log.append("Lua error: ").append(e.message ?: e.toString())
        } catch (e: Exception) {
            log.append("Error: ").append(e.message ?: e.toString())
        }
        return log.toString()
    }

    private fun appendOutput(text: String) {
        output.append(text)
    }

    private fun saveFile() {
        val name = currentFileName
        if (name == null) {
            promptForFileName { chosen ->
                currentFileName = chosen
                fileManager.write(chosen, editor.text.toString())
                tvFileName.text = if (chosen.endsWith(".lua")) chosen else "$chosen.lua"
                Toast.makeText(this, "Saved", Toast.LENGTH_SHORT).show()
            }
        } else {
            fileManager.write(name, editor.text.toString())
            Toast.makeText(this, "Saved", Toast.LENGTH_SHORT).show()
        }
    }

    private fun promptForFileName(onChosen: (String) -> Unit) {
        val input = EditText(this)
        input.hint = getString(R.string.file_name_hint)
        AlertDialog.Builder(this)
            .setTitle(R.string.new_file)
            .setView(input)
            .setPositiveButton(R.string.save) { _, _ ->
                val name = input.text.toString().trim()
                if (name.isNotEmpty()) onChosen(name)
            }
            .setNegativeButton(R.string.cancel, null)
            .show()
    }

    private fun showFileExplorer() {
        val files = fileManager.listScripts().toMutableList()
        val options = files.toMutableList()
        options.add(0, "+ ${getString(R.string.new_file)}")

        AlertDialog.Builder(this)
            .setTitle(R.string.files)
            .setItems(options.toTypedArray()) { _, which ->
                if (which == 0) {
                    promptForFileName { chosen ->
                        currentFileName = chosen
                        editor.setText("")
                        tvFileName.text = if (chosen.endsWith(".lua")) chosen else "$chosen.lua"
                        fileManager.write(chosen, "")
                    }
                } else {
                    val name = files[which - 1]
                    currentFileName = name
                    editor.setText(fileManager.read(name))
                    tvFileName.text = name
                }
            }
            .setNegativeButton(R.string.cancel, null)
            .show()
    }
}
