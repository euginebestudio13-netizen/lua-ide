package com.luaide.app

import android.graphics.Color
import android.text.Editable
import android.text.Spannable
import android.text.style.ForegroundColorSpan
import android.text.style.StyleSpan
import android.graphics.Typeface
import java.util.regex.Pattern

/**
 * Lightweight regex-based Lua syntax highlighter.
 * Applied after each text change; cheap enough for typical script sizes.
 */
object LuaHighlighter {

    private val KEYWORDS = Regex(
        "\\b(and|break|do|else|elseif|end|false|for|function|goto|if|in|" +
        "local|nil|not|or|repeat|return|then|true|until|while)\\b"
    )
    private val BUILTINS = Regex(
        "\\b(print|pairs|ipairs|type|tostring|tonumber|require|pcall|xpcall|" +
        "setmetatable|getmetatable|rawget|rawset|table|string|math|os|io|" +
        "next|select|error|assert|unpack)\\b"
    )
    private val STRING = Regex("\"(?:\\\\.|[^\"\\\\])*\"|'(?:\\\\.|[^'\\\\])*'")
    private val COMMENT = Regex("--\\[\\[[\\s\\S]*?]]|--[^\\n]*")
    private val NUMBER = Regex("\\b\\d+\\.?\\d*\\b")
    private val FUNCTION_NAME = Regex("(?<=function\\s)[A-Za-z_][A-Za-z0-9_.:]*")

    private const val COLOR_KEYWORD = 0xFFC678DD.toInt()
    private const val COLOR_BUILTIN = 0xFF61AFEF.toInt()
    private const val COLOR_STRING = 0xFF98C379.toInt()
    private const val COLOR_COMMENT = 0xFF7F848E.toInt()
    private const val COLOR_NUMBER = 0xFFD19A66.toInt()
    private const val COLOR_FUNCNAME = 0xFFE5C07B.toInt()

    fun highlight(editable: Editable) {
        val text = editable.toString()

        // Clear previous spans we own
        val spans = editable.getSpans(0, editable.length, ForegroundColorSpan::class.java)
        for (s in spans) editable.removeSpan(s)
        val boldSpans = editable.getSpans(0, editable.length, StyleSpan::class.java)
        for (s in boldSpans) editable.removeSpan(s)

        applyPattern(editable, text, NUMBER, COLOR_NUMBER)
        applyPattern(editable, text, KEYWORDS, COLOR_KEYWORD, bold = true)
        applyPattern(editable, text, BUILTINS, COLOR_BUILTIN)
        applyPattern(editable, text, FUNCTION_NAME, COLOR_FUNCNAME, bold = true)
        applyPattern(editable, text, STRING, COLOR_STRING)
        applyPattern(editable, text, COMMENT, COLOR_COMMENT)
    }

    private fun applyPattern(
        editable: Editable,
        text: String,
        regex: Regex,
        color: Int,
        bold: Boolean = false
    ) {
        for (match in regex.findAll(text)) {
            editable.setSpan(
                ForegroundColorSpan(color),
                match.range.first,
                match.range.last + 1,
                Spannable.SPAN_EXCLUSIVE_EXCLUSIVE
            )
            if (bold) {
                editable.setSpan(
                    StyleSpan(Typeface.BOLD),
                    match.range.first,
                    match.range.last + 1,
                    Spannable.SPAN_EXCLUSIVE_EXCLUSIVE
                )
            }
        }
    }
}
