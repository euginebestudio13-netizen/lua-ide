package com.luaide.app

import android.content.Context
import java.io.File

/**
 * Handles Lua script persistence in the app's private scripts/ folder.
 */
class FileManager(private val context: Context) {

    private val scriptsDir: File
        get() {
            val dir = File(context.filesDir, "scripts")
            if (!dir.exists()) dir.mkdirs()
            return dir
        }

    fun listScripts(): List<String> =
        scriptsDir.listFiles { f -> f.isFile && f.name.endsWith(".lua") }
            ?.map { it.name }
            ?.sorted()
            ?: emptyList()

    fun read(name: String): String {
        val f = File(scriptsDir, name)
        return if (f.exists()) f.readText() else ""
    }

    fun write(name: String, content: String) {
        val safeName = if (name.endsWith(".lua")) name else "$name.lua"
        File(scriptsDir, safeName).writeText(content)
    }

    fun delete(name: String): Boolean = File(scriptsDir, name).delete()

    fun rename(oldName: String, newName: String): Boolean {
        val target = if (newName.endsWith(".lua")) newName else "$newName.lua"
        return File(scriptsDir, oldName).renameTo(File(scriptsDir, target))
    }

    fun exists(name: String): Boolean {
        val safeName = if (name.endsWith(".lua")) name else "$name.lua"
        return File(scriptsDir, safeName).exists()
    }
}
